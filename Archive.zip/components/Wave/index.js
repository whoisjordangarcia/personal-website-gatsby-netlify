export { default } from './Wave';
