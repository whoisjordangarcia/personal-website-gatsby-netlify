module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 27);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("styled-components");

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(1);

// CONCATENATED MODULE: ./components/_styles/media.js
 // in px.

var sizes = {
  extraLarge: 1200,
  large: 992,
  medium: 768,
  small: 576,
  extraSmall: 576
}; // iterate through the sizes and create a media template

var media = Object.keys(sizes).reduce(function (accumulator, label) {
  // use em in breakpoints to work properly cross-browser and support users
  // changing their browsers font-size: https://zellwk.com/blog/media-query-units/
  var emSize = sizes[label] / 16; // eslint-disable-next-line no-param-reassign

  accumulator[label] = function () {
    return Object(external_styled_components_["css"])(["@media (max-width:", "em){", ";}"], emSize, external_styled_components_["css"].apply(void 0, arguments));
  };

  return accumulator;
}, {});
/* harmony default export */ var _styles_media = (media);
// CONCATENATED MODULE: ./components/_styles/index.js
/* concated harmony reexport media */__webpack_require__.d(__webpack_exports__, "a", function() { return _styles_media; });


/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(1);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(4);

// EXTERNAL MODULE: ./components/_styles/index.js + 1 modules
var _styles = __webpack_require__(2);

// CONCATENATED MODULE: ./components/MovingBlob/MovingBlob.js
function _templateObject() {
  var data = _taggedTemplateLiteral(["\n    width: 100vw;\n  "]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var BLOB_ELEMENT = 'blob-path';

var MovingBlob_MovingBlob =
/*#__PURE__*/
function (_Component) {
  _inherits(MovingBlob, _Component);

  function MovingBlob() {
    _classCallCheck(this, MovingBlob);

    return _possibleConstructorReturn(this, _getPrototypeOf(MovingBlob).apply(this, arguments));
  }

  _createClass(MovingBlob, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.timeline = new external_gsap_["TimelineMax"]({
        repeat: -1,
        delay: 0,
        repeatDelay: 0,
        yoyo: true
      });
      this.timeline.to("#".concat(BLOB_ELEMENT), 10, {
        attr: {
          d: 'M424.063759,512.960181 C589.749184,512.960181 668.758983,398.389437 668.758983,232.704012 C668.758983,67.018587 515.685425,247.201383 350,247.201383 C184.314575,247.201383 65.1927567,251.942687 65.1927567,417.628111 C65.1927567,583.313536 258.378334,512.960181 424.063759,512.960181 Z'
        },
        ease: external_gsap_["Power0"].easeNone
      }).to("#".concat(BLOB_ELEMENT), 10, {
        attr: {
          d: 'M350,650 C515.685425,650 650,515.685425 650,350 C650,184.314575 515.685425,50 350,50 C184.314575,50 50,184.314575 50,350 C50,515.685425 184.314575,650 350,650 Z'
        },
        ease: external_gsap_["Power0"].easeNone
      }).to("#".concat(BLOB_ELEMENT), 10, {
        attr: {
          d: 'M482.684579,631.633162 C557.951654,611.941737 688.535756,305.629094 668.758983,232.704012 C624.920077,71.0519686 310.611926,93.7545435 175.976814,158.945583 C88.647753,201.230779 133.009134,294.163227 133.009134,459.848652 C133.009134,625.534077 324.532254,673.009083 482.684579,631.633162 Z'
        },
        ease: external_gsap_["Power0"].easeNone
      }).to("#".concat(BLOB_ELEMENT), 10, {
        attr: {
          d: 'M313.710743,460.890336 C480.667586,514.928605 543.483105,686.744126 598.471299,530.654445 C637.775123,419.086469 509.096977,215.76901 353.159719,164.814935 C218.365777,120.769651 102.263208,-64.3915219 74.1952049,94.0378774 C45.1766619,257.832586 156.565167,410.027642 313.710743,460.890336 Z'
        },
        ease: external_gsap_["Power0"].easeNone
      });
    }
  }, {
    key: "render",
    value: function render() {
      return external_react_default.a.createElement(SvgCanvas, null, external_react_default.a.createElement("path", {
        id: BLOB_ELEMENT,
        d: "M357.3774314311999,481.4943736665 C523.8311743285999,514.1496996232 593.0547699245999,572.6421755627002 626.2841355588,412.7554586619002 C650.035436402,279.7732080926002 511.7040258736,228.2067999961 351.9094181917,197.41525247359994 C204.89171636860002,170.79868735239992 87.59443042059003,60.781924561729824 70.63293614726,222.0825328355198 C53.09703061235999,386.6253979149998 196.85263718189992,450.75804768229995 357.3774314311999,481.4943736665 Z"
      }));
    }
  }]);

  return MovingBlob;
}(external_react_["Component"]);

_defineProperty(MovingBlob_MovingBlob, "defaultProps", {});


var SvgCanvas = external_styled_components_default.a.svg.attrs({
  width: 700,
  height: 700,
  xmlns: 'http://www.w3.org/2000/svg'
}).withConfig({
  displayName: "MovingBlob__SvgCanvas",
  componentId: "zdek6c-0"
})(["fill:rgb(238,80,80);", ";"], _styles["a" /* media */].small(_templateObject()));
// EXTERNAL MODULE: ./components/Wave/Wave.png
var Wave = __webpack_require__(16);
var Wave_default = /*#__PURE__*/__webpack_require__.n(Wave);

// CONCATENATED MODULE: ./components/Wave/Wave.js



function Wave_Wave() {
  return external_react_default.a.createElement(StyledWave, null);
}
var waveAnimation = Object(external_styled_components_["keyframes"])(["from{-webkit-transform:none;transform:none;}15%{-webkit-transform:translate3d(-20%,0,0) rotate3d(0,0,1,-10deg);transform:translate3d(-20%,0,0) rotate3d(0,0,1,-10deg);}30%{-webkit-transform:translate3d(10%,0,0) rotate3d(0,0,1,7deg);transform:translate3d(10%,0,0) rotate3d(0,0,1,7deg);}45%{-webkit-transform:translate3d(-15%,0,0) rotate3d(0,0,1,-10deg);transform:translate3d(-15%,0,0) rotate3d(0,0,1,-10deg);}60%{-webkit-transform:translate3d(10%,0,0) rotate3d(0,0,1,5deg);transform:translate3d(10%,0,0) rotate3d(0,0,1,5deg);}75%{-webkit-transform:translate3d(-5%,0,0) rotate3d(0,0,1,-2deg);transform:translate3d(-5%,0,0) rotate3d(0,0,1,-2deg);}to{-webkit-transform:none;transform:none;}"]);
var StyledWave = external_styled_components_default.a.span.withConfig({
  displayName: "Wave__StyledWave",
  componentId: "sc-3fg1gr-0"
})(["background-image:url(", ");width:30px;height:30px;margin-left:5px;margin-top:5px;cursor:pointer;display:inline-block;vertical-align:text-top;background-size:contain;background-repeat:no-repeat;background-position:center;animation-name:", ";animation-fill-mode:both;animation-delay:1.5s;animation-duration:3s;"], Wave_default.a, waveAnimation);
// CONCATENATED MODULE: ./components/Wave/index.js

// CONCATENATED MODULE: ./components/Elements/Heading.js

var Heading = external_styled_components_default.a.h1.withConfig({
  displayName: "Heading",
  componentId: "rpakdz-0"
})(["font-size:35px;font-weight:", ";line-height:45px;color:#4c4c4c;"], function (props) {
  return props.bold ? 700 : 300;
});
Heading.h1 = Heading;
Heading.h2 = external_styled_components_default()(Heading.withComponent('h2')).withConfig({
  displayName: "Heading__h2",
  componentId: "rpakdz-1"
})(["font-size:", ";"], function (props) {
  return props.fontSize || '35px';
});
Heading.h3 = external_styled_components_default()(Heading.withComponent('h3')).withConfig({
  displayName: "Heading__h3",
  componentId: "rpakdz-2"
})(["font-size:", ";"], function (props) {
  return props.fontSize || '35px';
});
Heading.h4 = external_styled_components_default()(Heading.withComponent('h4')).withConfig({
  displayName: "Heading__h4",
  componentId: "rpakdz-3"
})(["font-size:", ";"], function (props) {
  return props.fontSize || '35px';
});
Heading.h5 = external_styled_components_default()(Heading.withComponent('h5')).withConfig({
  displayName: "Heading__h5",
  componentId: "rpakdz-4"
})(["font-size:", ";"], function (props) {
  return props.fontSize || '35px';
});
Heading.h6 = external_styled_components_default()(Heading.withComponent('h6')).withConfig({
  displayName: "Heading__h6",
  componentId: "rpakdz-5"
})(["font-size:", ";"], function (props) {
  return props.fontSize || '35px';
});
/* harmony default export */ var Elements_Heading = (Heading);
// CONCATENATED MODULE: ./components/Elements/Link.js

/* harmony default export */ var Link = (external_styled_components_default.a.a.withConfig({
  displayName: "Link",
  componentId: "sc-1u6glu8-0"
})(["transition:all 0.3s ease;text-decoration:none;position:relative;color:", ";font-size:", ";font-weight:", ";border-bottom:2px solid transparent;&:hover{border-bottom:2px solid ", ";}&:visited{text-decoration:none;color:", ";}"], function (props) {
  return props.color || '#4c4c4c';
}, function (props) {
  return props.fontSize || '18px';
}, function (props) {
  return props.bold ? 'bold' : 'normal';
}, function (props) {
  return props.color || '#4c4c4c';
}, function (props) {
  return props.color || '#4c4c4c';
}));
// CONCATENATED MODULE: ./components/Elements/Paragraph.js

var StyledParagraph = external_styled_components_default.a.p.withConfig({
  displayName: "Paragraph__StyledParagraph",
  componentId: "vbkmgn-0"
})(["font-size:18px;line-height:25px;font-weight:300;color:#4c4c4c;"]);
/* harmony default export */ var Paragraph = (StyledParagraph);
// CONCATENATED MODULE: ./components/Elements/index.js



// CONCATENATED MODULE: ./components/index.js
/* concated harmony reexport MovingBlob */__webpack_require__.d(__webpack_exports__, "c", function() { return MovingBlob_MovingBlob; });
/* concated harmony reexport Wave */__webpack_require__.d(__webpack_exports__, "e", function() { return Wave_Wave; });
/* concated harmony reexport Heading */__webpack_require__.d(__webpack_exports__, "a", function() { return Elements_Heading; });
/* concated harmony reexport Link */__webpack_require__.d(__webpack_exports__, "b", function() { return Link; });
/* concated harmony reexport Paragraph */__webpack_require__.d(__webpack_exports__, "d", function() { return Paragraph; });




/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("gsap");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("@redux-beacon/google-analytics-gtag");

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(19);

// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(1);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);

// EXTERNAL MODULE: ./components/_styles/index.js + 1 modules
var _styles = __webpack_require__(2);

// EXTERNAL MODULE: ./components/index.js + 7 modules
var components = __webpack_require__(3);

// CONCATENATED MODULE: ./components/_templates/Information/Information.js
function _templateObject5() {
  var data = _taggedTemplateLiteral(["\n    padding-left: 0px;\n  "]);

  _templateObject5 = function _templateObject5() {
    return data;
  };

  return data;
}

function _templateObject4() {
  var data = _taggedTemplateLiteral(["\n    margin: 0 20px;\n  "]);

  _templateObject4 = function _templateObject4() {
    return data;
  };

  return data;
}

function _templateObject3() {
  var data = _taggedTemplateLiteral(["\n    margin: 0 20px;\n  "]);

  _templateObject3 = function _templateObject3() {
    return data;
  };

  return data;
}

function _templateObject2() {
  var data = _taggedTemplateLiteral(["\n    grid-template-columns: auto;\n    grid-template-rows: auto;\n    padding: 0 40px;\n  "]);

  _templateObject2 = function _templateObject2() {
    return data;
  };

  return data;
}

function _templateObject() {
  var data = _taggedTemplateLiteral(["\n    text-align: left;\n  "]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }






var SectionHeading = external_styled_components_default()(components["a" /* Heading */].h2).withConfig({
  displayName: "Information__SectionHeading",
  componentId: "zwu761-0"
})(["text-align:right;", ";"], _styles["a" /* media */].small(_templateObject()));
var Section = external_styled_components_default.a.section.withConfig({
  displayName: "Information__Section",
  componentId: "zwu761-1"
})(["display:grid;margin:20px auto;max-width:1000px;grid-template-columns:35% 65%;", ";", ";", ";"], _styles["a" /* media */].small(_templateObject2()), _styles["a" /* media */].medium(_templateObject3()), _styles["a" /* media */].large(_templateObject4()));
var Content = external_styled_components_default.a.div.withConfig({
  displayName: "Information__Content",
  componentId: "zwu761-2"
})(["padding-left:100px;", ";"], _styles["a" /* media */].small(_templateObject5()));
function Information(_ref) {
  var heading = _ref.heading,
      children = _ref.children;
  return external_react_default.a.createElement(Section, null, external_react_default.a.createElement(SectionHeading, {
    bold: true,
    fontSize: "18px"
  }, heading), external_react_default.a.createElement(Content, null, children));
}
Information.defaultProps = {
  children: null,
  heading: null
};
// EXTERNAL MODULE: ./images/emoji/man-technologist.png
var man_technologist = __webpack_require__(17);
var man_technologist_default = /*#__PURE__*/__webpack_require__.n(man_technologist);

// CONCATENATED MODULE: ./components/_templates/Intro/Intro.js
function Intro_templateObject3() {
  var data = Intro_taggedTemplateLiteral(["\n    transform: translateX(0%) translateY(-20%);\n    overflow: hidden;\n  "]);

  Intro_templateObject3 = function _templateObject3() {
    return data;
  };

  return data;
}

function Intro_templateObject2() {
  var data = Intro_taggedTemplateLiteral(["\n    margin-right: 0;\n  "]);

  Intro_templateObject2 = function _templateObject2() {
    return data;
  };

  return data;
}

function Intro_templateObject() {
  var data = Intro_taggedTemplateLiteral(["\n    flex-direction: column;\n    padding: 20px 40px;\n  "]);

  Intro_templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function Intro_taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }






function Intro() {
  return external_react_default.a.createElement(Wrapper, null, external_react_default.a.createElement(ProfilePhoto, {
    alt: "Profile",
    src: "/static/profile_photo.jpg"
  }), external_react_default.a.createElement(Info, null, external_react_default.a.createElement(components["a" /* Heading */].h2, null, "Hello! ", external_react_default.a.createElement(components["e" /* Wave */], null)), external_react_default.a.createElement(components["a" /* Heading */].h2, null, "I'm", " ", external_react_default.a.createElement("span", {
    style: {
      fontWeight: 'bold'
    }
  }, "Jordan Garcia"), ", a senior software engineer at", ' ', external_react_default.a.createElement(components["b" /* Link */], {
    fontSize: "35px",
    href: "https://www.invitae.com",
    target: "_blank",
    rel: "noopener noreferrer"
  }, "invitae"), ". An aussie ", '"aw-see"', " (\\\xE4-s\\) currently residing in new york.", ' ', external_react_default.a.createElement(EmojiImage, null))), external_react_default.a.createElement(BlobWrapper, null, external_react_default.a.createElement(components["c" /* MovingBlob */], null)));
}
var Wrapper = external_styled_components_default.a.header.withConfig({
  displayName: "Intro__Wrapper",
  componentId: "iczliy-0"
})(["align-items:center;display:flex;height:100vh;justify-content:center;padding:0 20px;", ";"], _styles["a" /* media */].small(Intro_templateObject()));
var ProfilePhoto = external_styled_components_default.a.img.withConfig({
  displayName: "Intro__ProfilePhoto",
  componentId: "iczliy-1"
})(["width:170px;height:170px;border-radius:50%;margin-right:80px;z-index:1;", ";"], _styles["a" /* media */].small(Intro_templateObject2()));
var Info = external_styled_components_default.a.div.withConfig({
  displayName: "Intro__Info",
  componentId: "iczliy-2"
})(["display:inline-block;vertical-align:top;max-width:750px;z-index:1;"]);
var EmojiImage = external_styled_components_default.a.span.withConfig({
  displayName: "Intro__EmojiImage",
  componentId: "iczliy-3"
})(["background-image:url(", ");background-size:contain;width:30px;height:30px;display:inline-block;"], man_technologist_default.a);
var BlobWrapper = external_styled_components_default.a.div.withConfig({
  displayName: "Intro__BlobWrapper",
  componentId: "iczliy-4"
})(["position:absolute;transform:translateX(-30%);", ";"], _styles["a" /* media */].small(Intro_templateObject3()));
// CONCATENATED MODULE: ./components/_templates/fontStyles.js
function fontStyles_templateObject() {
  var data = fontStyles_taggedTemplateLiteral(["\n@font-face {\n  font-family: 'Apercu';\n  src: url('/static/fonts/apercu/Apercu-Light.eot');\n  src: url('/static/fonts/apercu/Apercu-Light.eot?#iefix') format('embedded-opentype'),\n    url('/static/fonts/apercu/Apercu-Light.woff2') format('woff2'),\n    url('/static/fonts/apercu/Apercu-Light.woff') format('woff'),\n    url('/static/fonts/apercu/Apercu-Light.ttf') format('truetype'),\n    url('/static/fonts/apercu/Apercu-Light.svg#Apercu-Light') format('svg');\n  font-weight: 300;\n  font-style: normal;\n}\n\n@font-face {\n  font-family: 'Apercu';\n  src: url('/static/fonts/apercu/Apercu-Regular.eot');\n  src: url('/static/fonts/apercu/Apercu-Regular.eot?#iefix')\n      format('embedded-opentype'),\n    url('/static/fonts/apercu/Apercu-Regular.woff2') format('woff2'),\n    url('/static/fonts/apercu/Apercu-Regular.woff') format('woff'),\n    url('/static/fonts/apercu/Apercu-Regular.ttf') format('truetype'),\n    url('/static/fonts/apercu/Apercu-Regular.svg#Apercu-Regular') format('svg');\n  font-weight: 400;\n  font-style: normal;\n}\n\n@font-face {\n  font-family: 'Apercu';\n  src: url('./static/fonts/apercu/Apercu-Medium.eot');\n  src: url('./static/fonts/apercu/Apercu-Medium.eot?#iefix')\n      format('embedded-opentype'),\n    url('./static/fonts/apercu/Apercu-Medium.woff2') format('woff2'),\n    url('./static/fonts/apercu/Apercu-Medium.woff') format('woff'),\n    url('./static/fonts/apercu/Apercu-Medium.ttf') format('truetype'),\n    url('./static/fonts/apercu/Apercu-Medium.svg#Apercu-Medium') format('svg');\n  font-weight: 500;\n  font-style: normal;\n}\n\n@font-face {\n  font-family: 'Apercu';\n  src: url('./static/fonts/apercu/Apercu-Bold.eot');\n  src: url('./static/fonts/apercu/Apercu-Bold.eot?#iefix') format('embedded-opentype'),\n    url('./static/fonts/apercu/Apercu-Bold.woff2') format('woff2'),\n    url('./static/fonts/apercu/Apercu-Bold.woff') format('woff'),\n    url('./static/fonts/apercu/Apercu-Bold.ttf') format('truetype'),\n    url('./static/fonts/apercu/Apercu-Bold.svg#Apercu-Bold') format('svg');\n  font-weight: 700;\n  font-style: normal;\n}\n\nhtml,\nbody {\n  -moz-osx-font-smoothing: grayscale;\n  -webkit-font-smoothing: antialiased;\n  background-color: #fcfeff;\n  font-family: 'Apercu', 'Source Sans Pro', system, system-ui, -apple-system,\n    Roboto, Helvectica, Arial, sans-serif;\n  color: #4c4c4c;\n}\n"]);

  fontStyles_templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function fontStyles_taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }


var FontStyles = Object(external_styled_components_["createGlobalStyle"])(fontStyles_templateObject());
// CONCATENATED MODULE: ./components/_templates/index.js
/* concated harmony reexport Information */__webpack_require__.d(__webpack_exports__, "b", function() { return Information; });
/* concated harmony reexport Intro */__webpack_require__.d(__webpack_exports__, "c", function() { return Intro; });
/* concated harmony reexport FontStyles */__webpack_require__.d(__webpack_exports__, "a", function() { return FontStyles; });




/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GA_TRACKING_ID; });
var GA_TRACKING_ID = 'UA-86912357-1';

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "redux"
var external_redux_ = __webpack_require__(10);

// EXTERNAL MODULE: external "redux-devtools-extension"
var external_redux_devtools_extension_ = __webpack_require__(11);

// EXTERNAL MODULE: external "redux-thunk"
var external_redux_thunk_ = __webpack_require__(12);
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_);

// EXTERNAL MODULE: external "@redux-beacon/google-analytics-gtag"
var google_analytics_gtag_ = __webpack_require__(5);
var google_analytics_gtag_default = /*#__PURE__*/__webpack_require__.n(google_analytics_gtag_);

// CONCATENATED MODULE: ./store/middlewares/eventsMap.js

var eventsMap = {
  DOWNLOAD_CLICKED: Object(google_analytics_gtag_["trackEvent"])(function (action) {
    return {
      category: 'CV',
      action: 'click',
      label: action.target
    };
  }),
  EXTERNAL_CLICKED: Object(google_analytics_gtag_["trackEvent"])(function (action) {
    return {
      category: 'EXTERNAL',
      action: 'click',
      label: action.target
    };
  })
};
// EXTERNAL MODULE: external "redux-beacon"
var external_redux_beacon_ = __webpack_require__(13);

// EXTERNAL MODULE: ./constants.js
var constants = __webpack_require__(7);

// CONCATENATED MODULE: ./store/middlewares/gaMiddleware.js




var ga = google_analytics_gtag_default()(constants["a" /* GA_TRACKING_ID */]);
var gaMiddleware = Object(external_redux_beacon_["createMiddleware"])(eventsMap, ga);
// EXTERNAL MODULE: ./static/who-is-jordan-garcia.json
var who_is_jordan_garcia = __webpack_require__(14);

// CONCATENATED MODULE: ./store/app.js

var app_initialState = {
  data: null
};
var actionTypes = {
  DOWNLOAD_CLICKED: 'DOWNLOAD_CLICKED',
  EXTERNAL_CLICKED: 'EXTERNAL_CLICKED',
  SET_DATA: 'SET_DATA'
}; // SELECTORS

var getData = function getData(state) {
  return state.data;
}; // REDUCERS

var reducer = function reducer() {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : app_initialState;
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case actionTypes.SET_DATA:
      return Object.assign({}, state, {
        data: action.data
      });

    default:
      return state;
  }
}; // ACTIONS

var downloadClicked = function downloadClicked(target) {
  return function (dispatch) {
    return dispatch({
      type: actionTypes.DOWNLOAD_CLICKED,
      target: target
    });
  };
};
var externalClicked = function externalClicked(target) {
  return function (dispatch) {
    return dispatch({
      type: actionTypes.EXTERNAL_CLICKED,
      target: target
    });
  };
};
var setData = function setData(data) {
  return function (dispatch) {
    return dispatch({
      type: actionTypes.SET_DATA,
      data: data
    });
  };
};
var app_fetchData = function fetchData() {
  return function (dispatch) {
    return dispatch(setData(who_is_jordan_garcia));
  };
};
// CONCATENATED MODULE: ./store/createStore.js





function initializeStore() {
  var initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  return Object(external_redux_["createStore"])(reducer, initialState, Object(external_redux_devtools_extension_["composeWithDevTools"])(Object(external_redux_["applyMiddleware"])(external_redux_thunk_default.a, gaMiddleware)));
}
// CONCATENATED MODULE: ./store/index.js
/* concated harmony reexport initializeStore */__webpack_require__.d(__webpack_exports__, "e", function() { return initializeStore; });
/* unused concated harmony import reducer */
/* unused concated harmony import actionTypes */
/* concated harmony reexport downloadClicked */__webpack_require__.d(__webpack_exports__, "a", function() { return downloadClicked; });
/* concated harmony reexport externalClicked */__webpack_require__.d(__webpack_exports__, "b", function() { return externalClicked; });
/* concated harmony reexport fetchData */__webpack_require__.d(__webpack_exports__, "c", function() { return app_fetchData; });
/* concated harmony reexport getData */__webpack_require__.d(__webpack_exports__, "d", function() { return getData; });



/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("redux-devtools-extension");

/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("redux-thunk");

/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("redux-beacon");

/***/ }),
/* 14 */
/***/ (function(module) {

module.exports = {"background":["Software engineer on an assortment of technical projects, consistently recognised for achievements through my education and into my professional career. I enjoy discovering clever solutions to complex problems in all aspects of my field.","<strong>When I’m not in front of the computer screen coding</strong>, I’m probably finding the next place to eat on ‘The Infatuation’, exploring the five boroughs of new york, or crossing off another item on my bucket list."],"skills":[{"name":"Frontend","list":["React","Redux","Graphql","Webpack","Jest","Angular"]},{"name":"Backend","list":["Node","Golang","Python","Redix","MySQL","MongoDB"]},{"name":"Infra","list":["Docker","Ansible","NGINX"]},{"name":"Design","list":["Sketch","InDesign","Photoshop","Prototyping","Wireframing","User Testing"]}],"resume":"/static/jordan_garcia_oct_18_cv.pdf","contribution":{"url":"https://ghchart.rshah.org/EE5050/arickho","alt":"arickho 's Github chart"},"experience":[{"title":"Invitae, NYC","positions":[{"role":"Senior Software Engineer","from":"Nov 18’","to":"Present"}]},{"title":"TodayTix, NYC","positions":[{"role":"Senior Software Engineer","from":"Oct 17’","to":"Oct 18’"}]},{"title":"Tigerspike, NYC","positions":[{"role":"Senior Software Engineer","from":"Jul 16’","to":"Oct 17’"},{"role":"Software Engineer","from":"Sept 15’","to":"Jul 16’"}]},{"title":"Tigerspike, SYD","positions":[{"role":"Software Engineer","from":"Feb 14’","to":"Sept 15’"}]},{"title":"Simbiotic, PER","positions":[{"role":"Software Developer","from":"Jul 11’","to":"Jan 14’"}]},{"title":"Western Australia Police Airwing, PER","positions":[{"role":"Software Developer / Designer","from":"Jul 11’","to":"Nov 11’"}]}],"contacts":[{"name":"Instagram","url":"https://www.instagram.com/whoisjordangarcia/"},{"name":"Twitter","url":"https://twitter.com/whoismrgarcia"},{"name":"Email","url":"mailto:arickho@gmail.com"},{"name":"Linkedin","url":"https://www.linkedin.com/in/arickhogarcia/"},{"name":"Github","url":"https://github.com/arickho"}]};

/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/Wave-5e4bc1a571f1f716ab81967ece99b9c5.png";

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/man-technologist-d11673ffa2b96556de099bb026d784bc.png";

/***/ }),
/* 18 */,
/* 19 */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),
/* 20 */,
/* 21 */,
/* 22 */
/***/ (function(module, exports) {

module.exports = require("react-reveal/Fade");

/***/ }),
/* 23 */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(28);


/***/ }),
/* 28 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(0);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(15);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22);
/* harmony import */ var react_reveal_Fade__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3);
/* harmony import */ var _components_templates__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6);
/* harmony import */ var _components_styles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8);


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _templateObject5() {
  var data = _taggedTemplateLiteral(["\n    margin: 20px 40px;\n\n    ul li {\n      margin: 0 0 10px 0;\n      display: block;\n      float: left;\n      text-align: left;\n      width: 100%;\n    }\n  "]);

  _templateObject5 = function _templateObject5() {
    return data;
  };

  return data;
}

function _templateObject4() {
  var data = _taggedTemplateLiteral(["\n    display: inline-block;\n    text-align: left;\n    float: none;\n    width: 100%;\n    font-size: 12px;\n    margin-bottom: 10px;\n  "]);

  _templateObject4 = function _templateObject4() {
    return data;
  };

  return data;
}

function _templateObject3() {
  var data = _taggedTemplateLiteral(["\n    line-height: 15px;\n  "]);

  _templateObject3 = function _templateObject3() {
    return data;
  };

  return data;
}

function _templateObject2() {
  var data = _taggedTemplateLiteral(["\n    flex-wrap: wrap;\n\n    ul {\n      flex: 50%;\n    }\n  "]);

  _templateObject2 = function _templateObject2() {
    return data;
  };

  return data;
}

function _templateObject() {
  var data = _taggedTemplateLiteral(["\n    flex-wrap: wrap;\n\n    ul {\n      flex: 50%;\n    }\n  "]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }











var ResumeInformation = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_components_templates__WEBPACK_IMPORTED_MODULE_8__[/* Information */ "b"]).withConfig({
  displayName: "pages__ResumeInformation",
  componentId: "sc-15txxly-0"
})(["margin:10px 0;"]);
var ListHeading = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_components__WEBPACK_IMPORTED_MODULE_7__[/* Heading */ "a"].h3).withConfig({
  displayName: "pages__ListHeading",
  componentId: "sc-15txxly-1"
})(["font-weight:500;margin:0 10px 0 0;padding:0;"]);
var Lists = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.div.withConfig({
  displayName: "pages__Lists",
  componentId: "sc-15txxly-2"
})(["display:flex;flex-direction:row;ul{list-style:none;-webkit-padding-start:0;flex-grow:1;li{font-size:18px;margin-bottom:5px;font-weight:300;}}", ";", ";"], _components_styles__WEBPACK_IMPORTED_MODULE_9__[/* media */ "a"].small(_templateObject()), _components_styles__WEBPACK_IMPORTED_MODULE_9__[/* media */ "a"].medium(_templateObject2()));
var GithubImage = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.img.withConfig({
  displayName: "pages__GithubImage",
  componentId: "sc-15txxly-3"
})(["margin-top:25px;width:100%;"]);
var CompanyWrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.div.withConfig({
  displayName: "pages__CompanyWrapper",
  componentId: "sc-15txxly-4"
})(["display:flex;flex-direction:column;margin-bottom:20px;"]);
var CompanyHeading = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_components__WEBPACK_IMPORTED_MODULE_7__[/* Heading */ "a"].h3).withConfig({
  displayName: "pages__CompanyHeading",
  componentId: "sc-15txxly-5"
})(["font-weight:500;margin:0;padding:0;"]);
var CompanyContent = styled_components__WEBPACK_IMPORTED_MODULE_3___default()(_components__WEBPACK_IMPORTED_MODULE_7__[/* Paragraph */ "d"]).withConfig({
  displayName: "pages__CompanyContent",
  componentId: "sc-15txxly-6"
})(["margin:0;padding:0;width:100%;", ";"], _components_styles__WEBPACK_IMPORTED_MODULE_9__[/* media */ "a"].small(_templateObject3()));
var CompanyDuration = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.span.withConfig({
  displayName: "pages__CompanyDuration",
  componentId: "sc-15txxly-7"
})(["text-align:right;float:right;font-size:14px;", ";"], _components_styles__WEBPACK_IMPORTED_MODULE_9__[/* media */ "a"].small(_templateObject4()));
var FooterSection = styled_components__WEBPACK_IMPORTED_MODULE_3___default.a.footer.withConfig({
  displayName: "pages__FooterSection",
  componentId: "sc-15txxly-8"
})(["display:grid;margin:50px 50px 20px 50px;ul{list-style:none;float:right;-webkit-padding-start:0;li{float:right;text-align:right;margin-left:20px;min-width:100px;}}", ";"], _components_styles__WEBPACK_IMPORTED_MODULE_9__[/* media */ "a"].small(_templateObject5()));

var Index =
/*#__PURE__*/
function (_Component) {
  _inherits(Index, _Component);

  function Index() {
    var _getPrototypeOf2;

    var _this;

    _classCallCheck(this, Index);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(Index)).call.apply(_getPrototypeOf2, [this].concat(args)));

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleOnDownloadCVClick", function (event) {
      _this.props.downloadClicked(event.target.href);
    });

    _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleOnLinkClick", function (event) {
      _this.props.externalClicked(event.target.href);
    });

    return _this;
  }

  _createClass(Index, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var data = this.props.data;
      var backgroundParagraphs = data.background,
          skillsList = data.skills,
          resumeLink = data.resume,
          contribution = data.contribution,
          experienceList = data.experience,
          contacts = data.contacts;
      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_6___default.a, null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("title", null, "Who is Jordan Garcia?")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_templates__WEBPACK_IMPORTED_MODULE_8__[/* Intro */ "c"], null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(react_reveal_Fade__WEBPACK_IMPORTED_MODULE_5___default.a, {
        bottom: true
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_templates__WEBPACK_IMPORTED_MODULE_8__[/* Information */ "b"], {
        heading: "BACKGROUND"
      }, backgroundParagraphs.map(function (backgroundParagraph) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components__WEBPACK_IMPORTED_MODULE_7__[/* Paragraph */ "d"], {
          key: backgroundParagraph,
          dangerouslySetInnerHTML: {
            __html: backgroundParagraph
          }
        });
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_templates__WEBPACK_IMPORTED_MODULE_8__[/* Information */ "b"], {
        heading: "SKILLS"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(Lists, null, skillsList.map(function (skill) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("ul", {
          key: skill.name
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ListHeading, {
          fontSize: "18px"
        }, skill.name)), skill.list.map(function (item) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", {
            key: item
          }, item);
        }));
      }))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(ResumeInformation, null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components__WEBPACK_IMPORTED_MODULE_7__[/* Link */ "b"], {
        bold: true,
        color: "#ee5050",
        fontSize: "22px",
        href: resumeLink,
        target: "_blank",
        rel: "noopener noreferrer",
        onClick: this.handleOnDownloadCVClick
      }, "View my resume"))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_templates__WEBPACK_IMPORTED_MODULE_8__[/* Information */ "b"], {
        heading: "CONTRIBUTION"
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(GithubImage, {
        src: contribution.url,
        alt: contribution.alt
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components_templates__WEBPACK_IMPORTED_MODULE_8__[/* Information */ "b"], {
        heading: "EXPERIENCE"
      }, experienceList.map(function (experience) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(CompanyWrapper, {
          key: experience.title
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(CompanyHeading, {
          fontSize: "18px"
        }, experience.title), experience.positions.map(function (position) {
          return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(CompanyContent, {
            key: position.role
          }, position.role, ' ', react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(CompanyDuration, null, position.from, " - ", position.to));
        }));
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(FooterSection, null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("ul", null, contacts.map(function (contact) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", {
          key: contact
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_components__WEBPACK_IMPORTED_MODULE_7__[/* Link */ "b"], {
          bold: true,
          color: "#ee5050",
          fontSize: "18px",
          href: contact.url,
          target: "_blank",
          rel: "noopener noreferrer",
          onClick: _this2.handleOnLinkClick
        }, contact.name));
      }))))));
    }
  }], [{
    key: "getInitialProps",
    value: function () {
      var _getInitialProps = _asyncToGenerator(
      /*#__PURE__*/
      _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(_ref) {
        var reduxStore;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                reduxStore = _ref.reduxStore;
                reduxStore.dispatch(Object(_store__WEBPACK_IMPORTED_MODULE_10__[/* fetchData */ "c"])());
                return _context.abrupt("return", {});

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function getInitialProps(_x) {
        return _getInitialProps.apply(this, arguments);
      };
    }()
  }]);

  return Index;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_4__["connect"])(function (state) {
  return {
    data: Object(_store__WEBPACK_IMPORTED_MODULE_10__[/* getData */ "d"])(state)
  };
}, {
  downloadClicked: _store__WEBPACK_IMPORTED_MODULE_10__[/* downloadClicked */ "a"],
  externalClicked: _store__WEBPACK_IMPORTED_MODULE_10__[/* externalClicked */ "b"]
})(Index));

/***/ })
/******/ ]);