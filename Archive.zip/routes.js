module.exports = () => {
  return {
    '/': { page: '/' }
  };
};
