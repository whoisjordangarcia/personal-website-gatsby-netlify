export { default as Information } from './Information/Information';
export { default as Intro } from './Intro/Intro';
export { FontStyles } from './fontStyles';
