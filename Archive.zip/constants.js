export const GA_TRACKING_ID = 'UA-86912357-1';
